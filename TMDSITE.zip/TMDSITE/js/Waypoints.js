$('.icons').css('opacity', 0);
$('.icons').waypoint(function() {
    $('.icons').addClass('animated boucelnInDown');
    $('.icons').css('opacity', 0);
    
}, {offset:'0%'}); //how far down the page loads



